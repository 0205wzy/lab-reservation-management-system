CREATE DATABASE IF NOT EXISTS lab_management
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;
USE lab_management;
SET NAMES utf8mb4;

CREATE TABLE sys_user (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  username VARCHAR(50) NOT NULL UNIQUE,
  password_hash VARCHAR(120) NOT NULL,
  real_name VARCHAR(50),
  phone VARCHAR(30),
  role VARCHAR(30) NOT NULL,
  status TINYINT DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE lab (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(100) NOT NULL,
  location VARCHAR(150),
  capacity INT,
  manager VARCHAR(50),
  phone VARCHAR(30),
  description VARCHAR(500),
  open_time VARCHAR(10),
  close_time VARCHAR(10),
  open_status TINYINT DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE lab_admin_assignment (
  user_id BIGINT NOT NULL,
  lab_id BIGINT NOT NULL,
  PRIMARY KEY (user_id, lab_id),
  UNIQUE KEY uq_lab_admin_assignment_lab (lab_id),
  CONSTRAINT fk_lab_admin_user FOREIGN KEY (user_id) REFERENCES sys_user (id),
  CONSTRAINT fk_lab_admin_lab FOREIGN KEY (lab_id) REFERENCES lab (id)
) ENGINE=InnoDB;

CREATE TABLE device (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  device_code VARCHAR(50) NOT NULL UNIQUE,
  name VARCHAR(100) NOT NULL,
  category VARCHAR(50),
  model VARCHAR(100),
  lab_id BIGINT,
  purchase_date DATE,
  status VARCHAR(30),
  remark VARCHAR(500),
  CONSTRAINT fk_device_lab FOREIGN KEY (lab_id) REFERENCES lab (id)
) ENGINE=InnoDB;

CREATE TABLE reservation (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  applicant_id BIGINT NOT NULL,
  lab_id BIGINT NOT NULL,
  reserve_date DATE NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  purpose VARCHAR(255),
  participants INT,
  remark VARCHAR(500),
  status VARCHAR(30),
  reject_reason VARCHAR(500),
  auditor_id BIGINT,
  audit_time DATETIME,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_reservation_conflict (lab_id, reserve_date, start_time, end_time, status),
  CONSTRAINT fk_res_user FOREIGN KEY (applicant_id) REFERENCES sys_user (id),
  CONSTRAINT fk_res_lab FOREIGN KEY (lab_id) REFERENCES lab (id),
  CONSTRAINT fk_res_auditor FOREIGN KEY (auditor_id) REFERENCES sys_user (id)
) ENGINE=InnoDB;

CREATE TABLE repair_order (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  device_id BIGINT NOT NULL,
  reporter_id BIGINT NOT NULL,
  handler_id BIGINT,
  fault_desc VARCHAR(500),
  severity VARCHAR(30),
  remark VARCHAR(500),
  status VARCHAR(30),
  result VARCHAR(500),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  completed_at DATETIME,
  INDEX idx_repair_active (device_id, status),
  CONSTRAINT fk_repair_device FOREIGN KEY (device_id) REFERENCES device (id),
  CONSTRAINT fk_repair_reporter FOREIGN KEY (reporter_id) REFERENCES sys_user (id),
  CONSTRAINT fk_repair_handler FOREIGN KEY (handler_id) REFERENCES sys_user (id)
) ENGINE=InnoDB;

CREATE TABLE operation_log (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  operator_id BIGINT,
  module VARCHAR(50),
  action VARCHAR(100),
  result VARCHAR(30),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_log_operator FOREIGN KEY (operator_id) REFERENCES sys_user (id)
) ENGINE=InnoDB;

INSERT INTO sys_user (id, username, password_hash, real_name, role, status) VALUES
  (1, 'demo_student', '{bcrypt}$2a$10$A.i2zhpzKw4ajzgIn0mWUOUKnVukAkt2iBpkERs0n/bQngjDdtaiC', '演示学生', 'USER', 1),
  (2, 'demo_lab_admin', '{bcrypt}$2a$10$A.i2zhpzKw4ajzgIn0mWUOUKnVukAkt2iBpkERs0n/bQngjDdtaiC', '演示实验室管理员', 'LAB_ADMIN', 1),
  (3, 'demo_system_admin', '{bcrypt}$2a$10$A.i2zhpzKw4ajzgIn0mWUOUKnVukAkt2iBpkERs0n/bQngjDdtaiC', '演示系统管理员', 'SYSTEM_ADMIN', 1);

INSERT INTO lab (id, name, location, capacity, manager, description, open_time, close_time, open_status) VALUES
  (1, '软件工程实验室', '科技楼 A301', 60, '演示实验室管理员', '用于软件开发、课程实验与项目训练', '08:00', '21:30', 1),
  (2, '人工智能实验室', '科技楼 B405', 40, '演示实验室管理员', '支持机器学习与人工智能实验', '08:30', '20:30', 1),
  (3, '物联网创新实验室', '实验楼 C208', 32, '演示实验室管理员', '用于嵌入式、传感器和物联网实践', '09:00', '18:00', 1);

INSERT INTO lab_admin_assignment (user_id, lab_id) VALUES (2, 1), (2, 2);

INSERT INTO device (id, device_code, name, category, model, lab_id, purchase_date, status, remark) VALUES
  (1, 'DEMO-PC-001', '开发工作站', '计算机', '演示型号', 1, '2025-03-15', 'NORMAL', '演示设备'),
  (2, 'DEMO-AI-001', 'AI 实验服务器', '服务器', '演示型号', 2, '2025-05-20', 'NORMAL', '演示设备'),
  (3, 'DEMO-IOT-001', '物联网实验箱', '开发板', '演示型号', 3, '2024-09-01', 'FAULT', '演示报修设备'),
  (4, 'DEMO-PJ-001', '实验室投影仪', '投影设备', '演示型号', 1, '2024-06-12', 'NORMAL', '演示设备');

INSERT INTO reservation (id, applicant_id, lab_id, reserve_date, start_time, end_time, purpose, participants, status, auditor_id, audit_time) VALUES
  (1, 1, 1, DATE_ADD(CURDATE(), INTERVAL 2 DAY), '14:00', '16:00', '课程小组讨论（演示预约）', 12, 'PENDING', NULL, NULL),
  (2, 1, 2, DATE_ADD(CURDATE(), INTERVAL 5 DAY), '09:00', '11:00', '机器学习实验（演示预约）', 8, 'APPROVED', 2, CURRENT_TIMESTAMP);

INSERT INTO repair_order (id, device_id, reporter_id, fault_desc, severity, status) VALUES
  (1, 3, 1, '实验箱传感器接口异常（演示报修）', 'MEDIUM', 'PENDING');
