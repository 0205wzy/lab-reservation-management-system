package com.zjnu.lab.security;
import io.jsonwebtoken.Claims; import jakarta.servlet.*; import jakarta.servlet.http.*;
import lombok.RequiredArgsConstructor; import org.springframework.security.authentication.UsernamePasswordAuthenticationToken; import org.springframework.security.core.authority.SimpleGrantedAuthority; import org.springframework.security.core.context.SecurityContextHolder; import org.springframework.stereotype.Component; import org.springframework.web.filter.OncePerRequestFilter;
import java.io.IOException; import java.util.List;
@Component @RequiredArgsConstructor public class JwtFilter extends OncePerRequestFilter {
 private final JwtUtil jwt;
 @Override protected void doFilterInternal(HttpServletRequest req,HttpServletResponse res,FilterChain chain)throws ServletException,IOException{
  String h=req.getHeader("Authorization");
  if(h!=null&&h.startsWith("Bearer ")) try{ Claims c=jwt.parse(h.substring(7)); String role=c.get("role",String.class); var a=new UsernamePasswordAuthenticationToken(c.getSubject(),null,List.of(new SimpleGrantedAuthority("ROLE_"+role))); a.setDetails(c.get("id",Long.class)); SecurityContextHolder.getContext().setAuthentication(a); }catch(Exception ignored){}
  chain.doFilter(req,res);
 }
}
