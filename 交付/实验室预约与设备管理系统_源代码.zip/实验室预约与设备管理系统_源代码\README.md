# 实验室预约与设备管理系统

基于 Spring Boot 3、MyBatis、MySQL/H2 和 Vue 3 的实验室预约与设备管理项目。此源码包保留现有前后端结构，并附有用于新建空数据库的演示数据。未包含构建产物或已安装依赖。

## 已实现功能

- 登录、JWT 身份认证及 `USER`、`LAB_ADMIN`、`SYSTEM_ADMIN` 角色权限。
- 实验室与设备查询；系统管理员维护实验室，具备范围的管理员维护实验室设备。
- 学生预约实验室、查询可用时段、查看日历和取消预约；实验室管理员按实验室范围审核。
- 学生提交设备报修；管理员受理、完成或关闭工单，相关设备状态随维修流程更新。
- 管理看板、报表、系统用户及实验室管理员分配。
- 学生 AI 助手接口和页面。AI 默认关闭，需要自行配置可用的模型服务和 API Key。

功能范围以当前源码和接口为准；详见 [docs/API.md](./docs/API.md)。

## 目录结构

```text
backend/                       Spring Boot 后端及测试
  pom.xml
  src/main/java/               控制器、服务、映射器、实体、安全配置
  src/main/resources/          MySQL 配置、H2 演示 schema 与数据
  src/test/java/               现有自动化测试
frontend/                      Vue 3 + Vite 前端
  src/                         页面、组件、路由、状态及 API 调用
  package.json
  package-lock.json
database/lab_management.sql    MySQL 建库、建表及演示数据
docs/                          接口、验证、AI 使用及交付记录
```

## 环境要求

- JDK 17。
- Maven 3.8 或更高版本（没有 Maven Wrapper，需本机安装 Maven 并配置 `PATH`）。
- Node.js 18 或更高版本、npm。
- MySQL 8.0（使用 MySQL 运行时需要）；也可以使用内置 H2 内存库进行临时演示。
- Windows 10/11 和 VS Code 可按下列 PowerShell 命令操作。

当前项目依赖版本：Spring Boot 3.3.5、MyBatis Spring Boot 3.0.3、Vue 3.5、Vite 5。前端锁文件为 `frontend/package-lock.json`。

## 运行方式 A：H2 快速演示

H2 开发配置使用进程内存数据库，启动时创建并装载演示数据，停止后数据不保留；不会连接或更改 MySQL 数据库。

在 VS Code 打开项目根目录，新开 PowerShell 终端：

```powershell
cd backend
mvn package
java -jar target\lab-management-1.0.0.jar --spring.profiles.active=dev
```

另开终端启动前端：

```powershell
cd frontend
npm ci
npm run dev
```

前端地址为 <http://localhost:5173>，后端 API 为 <http://localhost:8080/api>。Vite 已将 `/api` 代理至后端。H2 模式适用于本地试用；数据重启即重置。

## 运行方式 B：MySQL

### 创建并初始化空数据库

确认 MySQL 服务已启动。在项目根目录打开 **CMD**（命令提示符）并执行：

```cmd
mysql -u root -p < database\lab_management.sql
```

按提示输入 MySQL 密码。脚本创建 `lab_management` 数据库、表、约束和演示数据。脚本**仅用于新建的空库**：它不包含删除或清空表的语句；如果目标库中已经存在同名表，导入会报错并停止，请勿为了重导入而手动清空现有数据。

### 配置数据库连接并启动后端

PowerShell 中设置当前终端会话的数据库连接参数，再启动后端（按需替换用户名、密码和连接地址）：

```powershell
$env:DB_URL = "jdbc:mysql://localhost:3306/lab_management?useUnicode=true&characterEncoding=utf8&serverTimezone=Asia/Shanghai&allowPublicKeyRetrieval=true&useSSL=false"
$env:DB_USERNAME = "root"
$env:DB_PASSWORD = "替换为本机MySQL密码"
$env:JWT_SECRET = "替换为至少32字节的随机密钥"
cd backend
mvn package
java -jar target\lab-management-1.0.0.jar
```

`DB_URL`、`DB_USERNAME`、`DB_PASSWORD`、`JWT_SECRET` 可按需设置；连接串默认指向 `localhost:3306/lab_management`。主配置不会在源码中保存数据库密码，JWT 默认值仅供本地演示，部署或共享环境必须设置自己的随机密钥。重新打开终端后需再次设置环境变量。

### 启动前端

另开 PowerShell 终端，在项目根目录执行：

```powershell
cd frontend
npm ci
npm run dev
```

前端 <http://localhost:5173>，后端 <http://localhost:8080/api>，Swagger UI <http://localhost:8080/api/swagger-ui.html>。若需要生成前端生产文件，可执行 `npm run build`；生成的 `dist/` 未纳入源码包。

## 演示账号

初始化 SQL 与 H2 演示数据均提供以下账号，密码存为 Spring Security `{bcrypt}` 哈希：

| 用户名 | 密码 | 角色 |
|---|---|---|
| `demo_student` | `Demo123456` | 学生（`USER`） |
| `demo_lab_admin` | `Demo123456` | 实验室管理员（`LAB_ADMIN`，分配软件工程及人工智能实验室） |
| `demo_system_admin` | `Demo123456` | 系统管理员（`SYSTEM_ADMIN`） |

仅限本地演示。部署环境应更换密码、JWT 密钥，并按实际安全策略管理账号。

## 核心流程演示

1. 以 `demo_student` 登录，在“实验室”查看实验室开放时间、容量，在“设备”查看设备清单。
2. 在“预约”选择实验室、日期、时段并填写用途和人数，提交后可在本人预约列表查看待审核预约。初始化数据中也有未来的待审核样例。
3. 退出后以 `demo_lab_admin` 登录，在其负责实验室的预约管理中审核；学生重新登录可查看审核结果。预约申请会校验开放时段、容量、时间刻度及已有预约冲突。
4. 学生在设备/报修页面选择设备并提交故障描述。管理员在维修工单中受理工单、填写处理结果并完成，设备状态会随维修状态改变。

不同角色看见的页面和数据范围受现有角色权限控制。

## 常见问题

- **连接 MySQL 失败**：确认 MySQL 服务、端口、数据库名和 `DB_*` 环境变量；只对空数据库执行初始化 SQL。
- **端口已占用**：关闭占用 8080 或 5173 的进程，或按项目现有配置调整端口；更改后同步检查 Vite 代理地址。
- **`mvn` 或 `npm` 无法识别**：安装 Maven/Node.js 并重启 VS Code，使环境变量 `PATH` 生效。
- **前端请求返回 401**：先在 <http://localhost:8080/api> 启动后端，退出并重新登录以刷新 JWT。
- **AI 助手不可用**：AI 默认关闭；按下节配置有效服务地址、模型和 API Key。未配置时该功能不可用，不会返回伪造回答。
- **Maven 下载依赖失败**：检查网络或 Maven 镜像设置，然后在 `backend` 目录重试。

## AI 助手配置

后端支持通过环境变量配置兼容 OpenAI API 的模型服务：

```powershell
$env:AI_ENABLED = "true"
$env:AI_BASE_URL = "https://api.openai.com/v1"
$env:AI_API_KEY = "替换为你自行申请的API Key"
$env:AI_MODEL = "gpt-4o-mini"
$env:AI_TIMEOUT = "15"
```

请不要将真实 API Key 提交或放入源码。未设置 Key 时 AI 功能不可用。项目既有历史 AI 工具使用情况未在本次整理中确认，详见 [docs/AI-USAGE.md](./docs/AI-USAGE.md)。
