INSERT INTO sys_user (id, username, password_hash, real_name, role, status) VALUES
  (1, 'demo_student', '{bcrypt}$2a$10$A.i2zhpzKw4ajzgIn0mWUOUKnVukAkt2iBpkERs0n/bQngjDdtaiC', '演示学生', 'USER', 1),
  (2, 'demo_lab_admin', '{bcrypt}$2a$10$A.i2zhpzKw4ajzgIn0mWUOUKnVukAkt2iBpkERs0n/bQngjDdtaiC', '演示实验室管理员', 'LAB_ADMIN', 1),
  (3, 'demo_system_admin', '{bcrypt}$2a$10$A.i2zhpzKw4ajzgIn0mWUOUKnVukAkt2iBpkERs0n/bQngjDdtaiC', '演示系统管理员', 'SYSTEM_ADMIN', 1);

INSERT INTO lab (id, name, location, capacity, manager, description, open_time, close_time, open_status) VALUES
  (1, '软件工程实验室', '科技楼 A301', 60, '演示实验室管理员', '用于软件开发、课程实验与项目训练', '08:00', '21:30', 1),
  (2, '人工智能实验室', '科技楼 B405', 40, '演示实验室管理员', '支持机器学习与人工智能实验', '08:30', '20:30', 1),
  (3, '物联网创新实验室', '实验楼 C208', 32, '演示实验室管理员', '用于嵌入式、传感器和物联网实践', '09:00', '18:00', 1);

INSERT INTO lab_admin_assignment (user_id, lab_id) VALUES (2, 1), (2, 2);

INSERT INTO device (id, device_code, name, category, model, lab_id, purchase_date, status, remark) VALUES
  (1, 'DEMO-PC-001', '开发工作站', '计算机', '演示型号', 1, DATE '2025-03-15', 'NORMAL', '演示设备'),
  (2, 'DEMO-AI-001', 'AI 实验服务器', '服务器', '演示型号', 2, DATE '2025-05-20', 'NORMAL', '演示设备'),
  (3, 'DEMO-IOT-001', '物联网实验箱', '开发板', '演示型号', 3, DATE '2024-09-01', 'FAULT', '演示报修设备'),
  (4, 'DEMO-PJ-001', '实验室投影仪', '投影设备', '演示型号', 1, DATE '2024-06-12', 'NORMAL', '演示设备');

INSERT INTO reservation (id, applicant_id, lab_id, reserve_date, start_time, end_time, purpose, participants, status, auditor_id, audit_time, created_at) VALUES
  (1, 1, 1, DATEADD('DAY', 2, CURRENT_DATE), '14:00', '16:00', '课程小组讨论（演示预约）', 12, 'PENDING', NULL, NULL, CURRENT_TIMESTAMP),
  (2, 1, 2, DATEADD('DAY', 5, CURRENT_DATE), '09:00', '11:00', '机器学习实验（演示预约）', 8, 'APPROVED', 2, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);

INSERT INTO repair_order (id, device_id, reporter_id, fault_desc, severity, status, created_at) VALUES
  (1, 3, 1, '实验箱传感器接口异常（演示报修）', 'MEDIUM', 'PENDING', CURRENT_TIMESTAMP);
