# 主要接口说明

所有接口统一使用 `/api` context path，浏览器请求需携带 `Authorization: Bearer <JWT>`，除登录、Swagger 与 API 文档外均需认证。角色名称对应数据库 `sys_user.role`。

| 方法 | 路径 | 说明 | 权限 |
|---|---|---|---|
| POST | `/api/auth/login` | 登录并获取 JWT 与当前用户信息 | 公开 |
| GET | `/api/auth/me` | 获取当前登录用户 | 已登录 |
| GET | `/api/dashboard` | 管理看板统计 | 实验室管理员、系统管理员 |
| GET | `/api/labs`、`/api/labs/{id}` | 查询实验室 | 已登录；实验室管理员受管理范围限制 |
| POST | `/api/manage/labs` | 新增实验室 | 系统管理员 |
| PUT/DELETE | `/api/manage/labs/{id}` | 修改或停用实验室 | 系统管理员或有范围的实验室管理员 |
| GET | `/api/devices` | 查询设备（支持关键字、状态、实验室筛选） | 已登录 |
| POST | `/api/manage/devices` | 新增设备 | 管理员；受实验室范围限制 |
| PUT | `/api/manage/devices/{id}` | 更新设备 | 管理员；受实验室范围限制 |
| GET | `/api/reservations/my` | 查询本人预约（可按状态筛选） | 学生 |
| GET | `/api/reservations/calendar` | 查询实验室预约日历 | 已登录；查询跨度最多 63 天 |
| GET | `/api/reservations/recommendations` | 按实验室、日期及时长推荐可用时段 | 已登录 |
| POST | `/api/reservations` | 提交预约申请 | 学生；校验开放时段、容量、冲突和 30 分钟刻度 |
| PUT | `/api/reservations/{id}/cancel` | 取消本人预约（开始前两小时以上） | 学生 |
| GET | `/api/manage/reservations` | 查询管理范围内的预约 | 实验室管理员 |
| PUT | `/api/manage/reservations/{id}/audit` | 通过或拒绝预约 | 实验室管理员 |
| GET | `/api/repairs/my` | 查询本人报修 | 学生 |
| POST | `/api/repairs` | 提交设备报修 | 学生 |
| GET | `/api/manage/repairs` | 查询管理范围内维修工单 | 管理员 |
| PUT | `/api/manage/repairs/{id}/handle` | 受理、完成或关闭工单 | 管理员 |
| GET | `/api/manage/reports` | 查询统计报表 | 管理员 |
| GET | `/api/manage/reports/export` | 导出统计报表 | 管理员 |
| GET | `/api/admin/users` | 查询用户 | 系统管理员 |
| PUT | `/api/admin/users/{id}` | 修改用户角色或状态 | 系统管理员 |
| GET | `/api/admin/lab-assignments` | 查询实验室管理员分配 | 系统管理员 |
| PUT | `/api/admin/users/{id}/labs` | 设置用户负责的实验室范围 | 系统管理员 |
| POST | `/api/ai/ask` | 学生向 AI 助手提问 | 学生；需配置模型服务 |

请求/响应结构以控制器实现为准。启动后端后可访问 <http://localhost:8080/api/swagger-ui.html> 查看 Swagger 文档。
